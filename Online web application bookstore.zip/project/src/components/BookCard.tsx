import React from 'react';
import { Book } from '../types';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import Button from './ui/Button';
import Rating from './ui/Rating';
import { ShoppingCart } from 'lucide-react';

interface BookCardProps {
  book: Book;
}

const BookCard: React.FC<BookCardProps> = ({ book }) => {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  
  const handleViewDetails = () => {
    navigate(`/books/${book.id}`);
  };
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(book);
  };
  
  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden transform transition duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer"
      onClick={handleViewDetails}
    >
      <div className="h-[200px] overflow-hidden">
        <img 
          src={book.coverImage} 
          alt={book.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 text-lg line-clamp-1">{book.title}</h3>
        <p className="text-gray-600 text-sm mt-1">by {book.author}</p>
        
        <div className="flex items-center mt-2">
          <Rating value={book.rating} size={16} showValue />
        </div>
        
        <div className="mt-3 flex items-center justify-between">
          <p className="font-bold text-gray-900">${book.price.toFixed(2)}</p>
          <Button 
            variant="primary"
            size="sm"
            onClick={handleAddToCart}
            className="gap-1"
          >
            <ShoppingCart size={16} />
            <span className="sr-only sm:not-sr-only sm:inline-block">Add</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BookCard;