import React from 'react';
import { Star, StarHalf } from 'lucide-react';

interface RatingProps {
  value: number;
  max?: number;
  size?: number;
  color?: string;
  className?: string;
  showValue?: boolean;
}

const Rating: React.FC<RatingProps> = ({
  value,
  max = 5,
  size = 16,
  color = 'text-yellow-500',
  className = '',
  showValue = false
}) => {
  // Calculate full and half stars
  const fullStars = Math.floor(value);
  const hasHalfStar = value % 1 >= 0.5;
  
  return (
    <div className={`flex items-center ${className}`}>
      <div className="flex">
        {[...Array(max)].map((_, i) => {
          if (i < fullStars) {
            // Full star
            return (
              <Star
                key={`star-${i}`}
                size={size}
                className={`${color} fill-current`}
              />
            );
          } else if (i === fullStars && hasHalfStar) {
            // Half star
            return (
              <StarHalf
                key={`star-${i}`}
                size={size}
                className={`${color} fill-current`}
              />
            );
          } else {
            // Empty star
            return (
              <Star
                key={`star-${i}`}
                size={size}
                className="text-gray-300"
              />
            );
          }
        })}
      </div>
      {showValue && (
        <span className="ml-1 text-sm text-gray-600">{value.toFixed(1)}</span>
      )}
    </div>
  );
};

export default Rating;