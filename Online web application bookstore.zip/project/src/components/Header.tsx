import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Book, ShoppingCart, User, Search, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import Button from './ui/Button';

const Header: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Handle scroll for transparent/solid header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setIsMenuOpen(false);
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(prev => !prev);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMenuOpen ? 'bg-white shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-blue-900"
          >
            <Book size={28} />
            <span className="font-bold text-xl">BookHaven</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors hover:text-blue-900 ${
                location.pathname === '/' ? 'text-blue-900' : 'text-gray-700'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/browse" 
              className={`text-sm font-medium transition-colors hover:text-blue-900 ${
                location.pathname.startsWith('/browse') ? 'text-blue-900' : 'text-gray-700'
              }`}
            >
              Browse
            </Link>
            <Link 
              to="/categories" 
              className={`text-sm font-medium transition-colors hover:text-blue-900 ${
                location.pathname.startsWith('/categories') ? 'text-blue-900' : 'text-gray-700'
              }`}
            >
              Categories
            </Link>
          </nav>

          {/* Desktop Search and User Controls */}
          <div className="hidden md:flex items-center space-x-4">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                placeholder="Search books..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-[180px] lg:w-[220px] rounded-full border border-gray-300 py-1.5 pl-9 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-900 focus:border-transparent"
              />
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            </form>
            
            <Link to="/cart" className="relative">
              <ShoppingCart size={22} />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-900 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            
            {isAuthenticated ? (
              <div className="relative group">
                <button className="flex items-center space-x-1">
                  <User size={22} />
                  <span className="text-sm font-medium">{user?.name?.split(' ')[0]}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 origin-top-right">
                  <div className="py-1">
                    <Link to="/account" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Account</Link>
                    <Link to="/orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Orders</Link>
                    <button 
                      onClick={logout}
                      className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                    >
                      Sign out
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <Button 
                variant="primary" 
                size="sm"
                onClick={() => navigate('/login')}
              >
                Sign In
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700" 
            onClick={toggleMenu}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="container mx-auto px-4 py-4">
            <form onSubmit={handleSearch} className="relative mb-4">
              <input
                type="text"
                placeholder="Search books..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-900 focus:border-transparent"
              />
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            </form>
            
            <nav className="flex flex-col space-y-3">
              <Link 
                to="/" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/' ? 'text-blue-900' : 'text-gray-700'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/browse" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-sm font-medium transition-colors ${
                  location.pathname.startsWith('/browse') ? 'text-blue-900' : 'text-gray-700'
                }`}
              >
                Browse
              </Link>
              <Link 
                to="/categories" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-sm font-medium transition-colors ${
                  location.pathname.startsWith('/categories') ? 'text-blue-900' : 'text-gray-700'
                }`}
              >
                Categories
              </Link>
              <Link 
                to="/cart" 
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center justify-between"
              >
                <span className="text-sm font-medium text-gray-700">Cart</span>
                {totalItems > 0 && (
                  <span className="bg-blue-900 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Link>
              
              {isAuthenticated ? (
                <>
                  <Link 
                    to="/account" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-sm font-medium text-gray-700"
                  >
                    My Account
                  </Link>
                  <Link 
                    to="/orders" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-sm font-medium text-gray-700"
                  >
                    My Orders
                  </Link>
                  <button 
                    onClick={() => {
                      logout();
                      setIsMenuOpen(false);
                    }}
                    className="text-sm font-medium text-red-600 text-left"
                  >
                    Sign out
                  </button>
                </>
              ) : (
                <Button 
                  variant="primary" 
                  size="sm"
                  onClick={() => {
                    navigate('/login');
                    setIsMenuOpen(false);
                  }}
                >
                  Sign In
                </Button>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;