export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  coverImage: string;
  rating: number;
  description: string;
  publicationDate: string;
  publisher: string;
  pages: number;
  categories: string[];
  language: string;
  format: string;
  isbn: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface CartItem {
  book: Book;
  quantity: number;
}

export interface Review {
  id: string;
  bookId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}