import { Book, Review } from '../types';

export const books: Book[] = [
  {
    id: '1',
    title: 'The Midnight Library',
    author: 'Matt Haig',
    price: 24.99,
    coverImage: 'https://images.pexels.com/photos/1370295/pexels-photo-1370295.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.5,
    description: 
      'Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived. To see how things would be if you had made other choices... Would you have done anything different, if you had the chance to undo your regrets?',
    publicationDate: '2020-08-13',
    publisher: 'Canongate Books',
    pages: 304,
    categories: ['Fiction', 'Fantasy', 'Contemporary'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9781786892720'
  },
  {
    id: '2',
    title: 'Atomic Habits',
    author: 'James Clear',
    price: 21.99,
    coverImage: 'https://images.pexels.com/photos/5157275/pexels-photo-5157275.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.8,
    description: 
      'No matter your goals, Atomic Habits offers a proven framework for improving--every day. James Clear, one of the world\'s leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.',
    publicationDate: '2018-10-16',
    publisher: 'Avery',
    pages: 320,
    categories: ['Self-Help', 'Personal Development', 'Psychology'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9780735211292'
  },
  {
    id: '3',
    title: 'Educated',
    author: 'Tara Westover',
    price: 19.99,
    coverImage: 'https://images.pexels.com/photos/694740/pexels-photo-694740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.7,
    description: 
      'Born to survivalists in the mountains of Idaho, Tara Westover was seventeen the first time she set foot in a classroom. Her family was so isolated from mainstream society that there was no one to ensure the children received an education, and no one to intervene when one of Tara\'s older brothers became violent.',
    publicationDate: '2018-02-20',
    publisher: 'Random House',
    pages: 352,
    categories: ['Memoir', 'Biography', 'Autobiography'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9780399590504'
  },
  {
    id: '4',
    title: 'The Silent Patient',
    author: 'Alex Michaelides',
    price: 22.99,
    coverImage: 'https://images.pexels.com/photos/5834331/pexels-photo-5834331.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.3,
    description: 
      'Alicia Berenson\'s life is seemingly perfect. A famous painter married to an in-demand fashion photographer, she lives in a grand house with big windows overlooking a park in one of London\'s most desirable areas. One evening her husband Gabriel returns home late from a fashion shoot, and Alicia shoots him five times in the face, and then never speaks another word.',
    publicationDate: '2019-02-05',
    publisher: 'Celadon Books',
    pages: 336,
    categories: ['Thriller', 'Mystery', 'Psychological Fiction'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9781250301697'
  },
  {
    id: '5',
    title: 'Where the Crawdads Sing',
    author: 'Delia Owens',
    price: 18.99,
    coverImage: 'https://images.pexels.com/photos/3747139/pexels-photo-3747139.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.6,
    description: 
      'For years, rumors of the "Marsh Girl" have haunted Barkley Cove, a quiet town on the North Carolina coast. So in late 1969, when handsome Chase Andrews is found dead, the locals immediately suspect Kya Clark, the so-called Marsh Girl. But Kya is not what they say. Sensitive and intelligent, she has survived for years alone in the marsh that she calls home.',
    publicationDate: '2018-08-14',
    publisher: 'G.P. Putnam\'s Sons',
    pages: 384,
    categories: ['Fiction', 'Mystery', 'Literary Fiction'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9780735219090'
  },
  {
    id: '6',
    title: 'Project Hail Mary',
    author: 'Andy Weir',
    price: 25.99,
    coverImage: 'https://images.pexels.com/photos/2203725/pexels-photo-2203725.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.9,
    description: 
      'Ryland Grace is the sole survivor on a desperate, last-chance mission—and if he fails, humanity and the Earth itself will perish. Except that right now, he doesn\'t know that. He can\'t even remember his own name, let alone the nature of his assignment or how to complete it.',
    publicationDate: '2021-05-04',
    publisher: 'Ballantine Books',
    pages: 496,
    categories: ['Science Fiction', 'Adventure', 'Space'],
    language: 'English',
    format: 'Hardcover',
    isbn: '9780593135204'
  }
];

export const reviews: Review[] = [
  {
    id: '1',
    bookId: '1',
    userId: '101',
    userName: 'Sarah Johnson',
    rating: 5,
    comment: 'This book changed my perspective on life. Highly recommend!',
    date: '2023-05-15'
  },
  {
    id: '2',
    bookId: '1',
    userId: '102',
    userName: 'Michael Chen',
    rating: 4,
    comment: 'Beautifully written with an interesting concept. The ending felt a bit rushed.',
    date: '2023-06-02'
  },
  {
    id: '3',
    bookId: '2',
    userId: '103',
    userName: 'Emma Wilson',
    rating: 5,
    comment: "Practical advice that actually works. I've implemented several habits already.",
    date: '2023-04-18'
  },
  {
    id: '4',
    bookId: '3',
    userId: '104',
    userName: 'David Miller',
    rating: 5,
    comment: 'An incredible story of resilience and the power of education.',
    date: '2023-03-22'
  },
  {
    id: '5',
    bookId: '4',
    userId: '105',
    userName: 'Jessica Taylor',
    rating: 4,
    comment: 'Gripping psychological thriller with a twist I didn't see coming.',
    date: '2023-07-09'
  }
];

export const categories = [
  'Fiction',
  'Non-Fiction',
  'Mystery',
  'Science Fiction',
  'Fantasy',
  'Biography',
  'Self-Help',
  'Romance',
  'Thriller',
  'Historical Fiction',
  'Business',
  'Children\'s'
];

export const featuredCollections = [
  {
    id: '1',
    title: 'New Releases',
    books: ['1', '4', '6']
  },
  {
    id: '2',
    title: 'Award Winners',
    books: ['3', '5']
  },
  {
    id: '3',
    title: 'Staff Picks',
    books: ['2', '6']
  }
];