import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Bookmark, Share2 } from 'lucide-react';
import { books, reviews } from '../data/books';
import { Book, Review } from '../types';
import { useCart } from '../context/CartContext';
import Button from '../components/ui/Button';
import Rating from '../components/ui/Rating';
import Badge from '../components/ui/Badge';
import BookCard from '../components/BookCard';

const BookDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [book, setBook] = useState<Book | null>(null);
  const [bookReviews, setBookReviews] = useState<Review[]>([]);
  const [relatedBooks, setRelatedBooks] = useState<Book[]>([]);
  const [quantity, setQuantity] = useState(1);
  
  useEffect(() => {
    // Fetch book details
    const bookData = books.find(b => b.id === id);
    if (bookData) {
      setBook(bookData);
      
      // Fetch book reviews
      const bookReviewData = reviews.filter(r => r.bookId === id);
      setBookReviews(bookReviewData);
      
      // Get related books (same category)
      const related = books
        .filter(b => b.id !== id && b.categories.some(cat => bookData.categories.includes(cat)))
        .slice(0, 6);
      setRelatedBooks(related);
    }
  }, [id]);

  const handleAddToCart = () => {
    if (book) {
      addToCart(book, quantity);
    }
  };
  
  if (!book) {
    return (
      <div className="min-h-screen bg-gray-50 pt-32 pb-20 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Loading...</h2>
          <p className="text-gray-600 mb-6">Getting book details</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-20">
      <div className="container mx-auto px-4">
        {/* Navigation */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-700 hover:text-blue-900 mb-8 transition-colors"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to Books
        </button>
        
        {/* Book Details */}
        <div className="bg-white shadow-md rounded-lg p-6 md:p-8 mb-12">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Book Image */}
            <div className="w-full md:w-1/3 lg:w-1/4">
              <div className="rounded-lg overflow-hidden shadow-xl h-auto aspect-[2/3]">
                <img 
                  src={book.coverImage} 
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            {/* Book Info */}
            <div className="w-full md:w-2/3 lg:w-3/4">
              <div className="flex flex-wrap gap-2 mb-3">
                {book.categories.map((category, index) => (
                  <Badge key={index} variant="default">
                    {category}
                  </Badge>
                ))}
              </div>
              
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                {book.title}
              </h1>
              
              <p className="text-lg text-gray-700 mb-4">by {book.author}</p>
              
              <div className="flex items-center mb-4">
                <Rating value={book.rating} size={18} showValue />
                <span className="ml-2 text-sm text-gray-600">
                  ({bookReviews.length} {bookReviews.length === 1 ? 'review' : 'reviews'})
                </span>
              </div>
              
              <div className="mb-6 pb-6 border-b border-gray-200">
                <p className="text-gray-700 leading-relaxed">{book.description}</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6 pb-6 border-b border-gray-200">
                <div>
                  <p className="text-sm text-gray-600">Publisher</p>
                  <p className="font-medium">{book.publisher}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Publication Date</p>
                  <p className="font-medium">{new Date(book.publicationDate).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Language</p>
                  <p className="font-medium">{book.language}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Pages</p>
                  <p className="font-medium">{book.pages}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Format</p>
                  <p className="font-medium">{book.format}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">ISBN</p>
                  <p className="font-medium">{book.isbn}</p>
                </div>
              </div>
              
              <div className="flex flex-wrap items-end gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Price</p>
                  <p className="text-2xl font-bold text-gray-900">${book.price.toFixed(2)}</p>
                </div>
                
                <div className="flex-grow">
                  <p className="text-sm text-gray-600 mb-1">Quantity</p>
                  <div className="flex w-32 max-w-full">
                    <button 
                      className="border border-gray-300 px-3 py-1 text-gray-700 hover:bg-gray-100 rounded-l-md"
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    >
                      -
                    </button>
                    <input 
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="border-y border-gray-300 w-full text-center py-1"
                    />
                    <button 
                      className="border border-gray-300 px-3 py-1 text-gray-700 hover:bg-gray-100 rounded-r-md"
                      onClick={() => setQuantity(q => q + 1)}
                    >
                      +
                    </button>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <Button 
                    size="lg"
                    onClick={handleAddToCart}
                  >
                    Add to Cart
                  </Button>
                  <Button 
                    variant="outline"
                    size="lg"
                    className="flex items-center gap-1"
                  >
                    <Bookmark size={16} />
                    Save
                  </Button>
                  <Button 
                    variant="ghost"
                    size="lg"
                    className="flex items-center gap-1"
                  >
                    <Share2 size={16} />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Reviews */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Customer Reviews</h2>
          
          {bookReviews.length > 0 ? (
            <div className="grid gap-6">
              {bookReviews.map(review => (
                <div key={review.id} className="bg-white shadow-md rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-medium text-gray-900">{review.userName}</h3>
                      <p className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</p>
                    </div>
                    <Rating value={review.rating} size={16} />
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white shadow-md rounded-lg p-6 text-center">
              <p className="text-gray-600">No reviews yet. Be the first to review this book!</p>
              <Button className="mt-4">Write a Review</Button>
            </div>
          )}
        </section>
        
        {/* Related Books */}
        {relatedBooks.length > 0 && (
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
              {relatedBooks.map(book => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default BookDetailPage;