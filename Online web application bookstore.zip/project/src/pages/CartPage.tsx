import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, ArrowLeft, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import Button from '../components/ui/Button';

const CartPage: React.FC = () => {
  const { items, removeFromCart, updateQuantity, totalItems, totalPrice, clearCart } = useCart();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const handleCheckout = () => {
    if (isAuthenticated) {
      navigate('/checkout');
    } else {
      navigate('/login?redirect=checkout');
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-20">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <button 
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-700 hover:text-blue-900 transition-colors"
          >
            <ArrowLeft size={16} className="mr-2" />
            Continue Shopping
          </button>
        </div>
        
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8">Your Cart</h1>
        
        {items.length > 0 ? (
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Cart Items */}
            <div className="flex-grow">
              <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="hidden md:grid grid-cols-12 gap-4 p-4 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-600">
                  <div className="col-span-6">Product</div>
                  <div className="col-span-2 text-center">Price</div>
                  <div className="col-span-2 text-center">Quantity</div>
                  <div className="col-span-2 text-center">Total</div>
                </div>
                
                {items.map((item) => (
                  <div 
                    key={item.book.id} 
                    className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4 border-b border-gray-200 items-center"
                  >
                    {/* Product */}
                    <div className="col-span-1 md:col-span-6 flex items-center gap-4">
                      <div 
                        className="w-16 h-24 bg-cover bg-center rounded-md overflow-hidden shrink-0"
                        style={{ backgroundImage: `url(${item.book.coverImage})` }}
                      ></div>
                      <div>
                        <h3 
                          className="font-medium text-gray-900 mb-1 hover:text-blue-900 cursor-pointer"
                          onClick={() => navigate(`/books/${item.book.id}`)}
                        >
                          {item.book.title}
                        </h3>
                        <p className="text-sm text-gray-600">by {item.book.author}</p>
                        <button 
                          onClick={() => removeFromCart(item.book.id)}
                          className="mt-2 flex items-center text-sm text-red-600 hover:text-red-700 md:hidden"
                        >
                          <Trash2 size={14} className="mr-1" />
                          Remove
                        </button>
                      </div>
                    </div>
                    
                    {/* Price */}
                    <div className="col-span-1 md:col-span-2 flex justify-between md:justify-center items-center">
                      <span className="md:hidden text-sm text-gray-600">Price:</span>
                      <span className="font-medium">${item.book.price.toFixed(2)}</span>
                    </div>
                    
                    {/* Quantity */}
                    <div className="col-span-1 md:col-span-2 flex justify-between md:justify-center items-center">
                      <span className="md:hidden text-sm text-gray-600">Quantity:</span>
                      <div className="flex">
                        <button 
                          className="border border-gray-300 px-2 py-1 text-gray-700 hover:bg-gray-100 rounded-l-md"
                          onClick={() => updateQuantity(item.book.id, Math.max(1, item.quantity - 1))}
                        >
                          -
                        </button>
                        <input 
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateQuantity(item.book.id, Math.max(1, parseInt(e.target.value) || 1))}
                          className="border-y border-gray-300 w-12 text-center py-1"
                        />
                        <button 
                          className="border border-gray-300 px-2 py-1 text-gray-700 hover:bg-gray-100 rounded-r-md"
                          onClick={() => updateQuantity(item.book.id, item.quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    
                    {/* Total */}
                    <div className="col-span-1 md:col-span-2 flex justify-between md:justify-center items-center">
                      <span className="md:hidden text-sm text-gray-600">Total:</span>
                      <span className="font-medium">${(item.book.price * item.quantity).toFixed(2)}</span>
                    </div>
                    
                    {/* Remove - Desktop Only */}
                    <button 
                      onClick={() => removeFromCart(item.book.id)}
                      className="hidden md:flex absolute right-4 text-gray-400 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
                
                <div className="p-4 flex justify-between">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => clearCart()}
                  >
                    Clear Cart
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Order Summary */}
            <div className="lg:w-80">
              <div className="bg-white shadow-md rounded-lg p-6">
                <h2 className="font-bold text-lg text-gray-900 mb-4">Order Summary</h2>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-gray-700">
                    <span>Subtotal ({totalItems} items)</span>
                    <span>${totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Tax</span>
                    <span>${(totalPrice * 0.07).toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-3 flex justify-between font-bold text-gray-900">
                    <span>Total</span>
                    <span>${(totalPrice + totalPrice * 0.07).toFixed(2)}</span>
                  </div>
                </div>
                
                <Button 
                  fullWidth 
                  size="lg"
                  onClick={handleCheckout}
                  className="flex justify-center items-center gap-2"
                >
                  <ShoppingBag size={18} />
                  Proceed to Checkout
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white shadow-md rounded-lg p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
              <ShoppingBag size={24} className="text-gray-400" />
            </div>
            <h2 className="text-xl font-medium text-gray-900 mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-6">
              Looks like you haven't added any books to your cart yet.
            </p>
            <Button 
              onClick={() => navigate('/browse')}
            >
              Browse Books
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;