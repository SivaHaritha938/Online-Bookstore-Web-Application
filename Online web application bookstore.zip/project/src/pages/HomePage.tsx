import React from 'react';
import { useNavigate } from 'react-router-dom';
import { books, categories, featuredCollections } from '../data/books';
import { ChevronRight, BookOpen } from 'lucide-react';
import BookCard from '../components/BookCard';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  
  // Get books for featured collections
  const getFeaturedCollectionBooks = (collectionId: string) => {
    const collection = featuredCollections.find(c => c.id === collectionId);
    if (!collection) return [];
    
    return collection.books.map(bookId => 
      books.find(book => book.id === bookId)
    ).filter(Boolean) as typeof books;
  };
  
  // Featured categories to show on homepage
  const featuredCategories = categories.slice(0, 6);
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[500px] md:h-[600px] bg-gradient-to-r from-blue-900 to-indigo-900 flex items-center">
        <div 
          className="absolute inset-0 opacity-20 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.pexels.com/photos/1907785/pexels-photo-1907785.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')" }}
        ></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
              Discover Your Next Favorite Book
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8">
              Explore our vast collection of books across all genres. From bestsellers to hidden gems, find your perfect read today.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                onClick={() => navigate('/browse')}
              >
                Browse Books
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border-white text-white hover:bg-white hover:text-blue-900"
                onClick={() => navigate('/categories')}
              >
                Explore Categories
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* New Releases */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">New Releases</h2>
            <Button 
              variant="ghost" 
              onClick={() => navigate('/browse?collection=new-releases')}
              className="flex items-center gap-1"
            >
              View All <ChevronRight size={16} />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {getFeaturedCollectionBooks('1').map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Categories */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8">Popular Categories</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {featuredCategories.map((category, index) => (
              <div 
                key={index}
                onClick={() => navigate(`/categories/${category.toLowerCase()}`)}
                className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <BookOpen size={20} className="text-blue-900" />
                </div>
                <h3 className="font-medium text-gray-900">{category}</h3>
                <p className="text-sm text-gray-500 mt-1">
                  {Math.floor(Math.random() * 100) + 20} Books
                </p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Button 
              onClick={() => navigate('/categories')}
              className="flex items-center gap-1 mx-auto"
            >
              All Categories <ChevronRight size={16} />
            </Button>
          </div>
        </div>
      </section>
      
      {/* Staff Picks */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <div>
              <Badge variant="success" className="mb-2">Staff Picks</Badge>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Recommended by Our Team</h2>
            </div>
            <Button 
              variant="ghost" 
              onClick={() => navigate('/browse?collection=staff-picks')}
              className="flex items-center gap-1"
            >
              View All <ChevronRight size={16} />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {getFeaturedCollectionBooks('3').map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Feature Banner */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="bg-blue-900 rounded-xl overflow-hidden shadow-xl">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Join Our Book Club</h2>
                <p className="text-blue-100 mb-6">
                  Connect with fellow book lovers, participate in discussions, and get exclusive access to author interviews and events.
                </p>
                <Button 
                  className="self-start bg-white text-blue-900 hover:bg-blue-50"
                  onClick={() => navigate('/book-club')}
                >
                  Learn More
                </Button>
              </div>
              <div 
                className="md:w-1/2 h-64 md:h-auto bg-cover bg-center"
                style={{ backgroundImage: "url('https://images.pexels.com/photos/5834831/pexels-photo-5834331.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')" }}
              ></div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Award Winners */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <div>
              <Badge variant="warning" className="mb-2">Award Winners</Badge>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Critically Acclaimed Books</h2>
            </div>
            <Button 
              variant="ghost" 
              onClick={() => navigate('/browse?collection=award-winners')}
              className="flex items-center gap-1"
            >
              View All <ChevronRight size={16} />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {getFeaturedCollectionBooks('2').map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;