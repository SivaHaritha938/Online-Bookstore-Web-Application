import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, Search, X } from 'lucide-react';
import { books, categories } from '../data/books';
import { Book } from '../types';
import BookCard from '../components/BookCard';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

const BrowsePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const initialCategory = searchParams.get('category') || '';
  
  const [query, setQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [filteredBooks, setFilteredBooks] = useState<Book[]>(books);
  const [showFilters, setShowFilters] = useState(false);
  
  // Apply filters
  useEffect(() => {
    let results = [...books];
    
    // Apply search filter
    if (query) {
      const searchLower = query.toLowerCase();
      results = results.filter(book => 
        book.title.toLowerCase().includes(searchLower) || 
        book.author.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply category filter
    if (selectedCategory) {
      results = results.filter(book => 
        book.categories.some(cat => cat.toLowerCase() === selectedCategory.toLowerCase())
      );
    }
    
    // Apply price filter
    results = results.filter(book => 
      book.price >= priceRange[0] && book.price <= priceRange[1]
    );
    
    setFilteredBooks(results);
  }, [query, selectedCategory, priceRange]);
  
  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (selectedCategory) params.set('category', selectedCategory);
    setSearchParams(params);
  }, [query, selectedCategory, setSearchParams]);
  
  const handleClearFilters = () => {
    setQuery('');
    setSelectedCategory('');
    setPriceRange([0, 100]);
    setSearchParams({});
  };
  
  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 md:mb-0">
            Browse Books
          </h1>
          
          <div className="flex items-center space-x-2">
            <Button 
              variant={showFilters ? "primary" : "outline"}
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-1 md:hidden"
            >
              <Filter size={16} />
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </Button>
            
            {(query || selectedCategory || priceRange[0] > 0 || priceRange[1] < 100) && (
              <Button 
                variant="secondary"
                size="sm"
                onClick={handleClearFilters}
                className="flex items-center gap-1"
              >
                <X size={16} />
                Clear Filters
              </Button>
            )}
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row">
          {/* Filters */}
          <div className={`md:w-64 md:block ${showFilters ? 'block' : 'hidden'}`}>
            <div className="bg-white rounded-lg shadow-md p-6 mb-6 md:sticky md:top-32">
              <h2 className="font-semibold text-gray-900 mb-4">Filters</h2>
              
              {/* Search */}
              <div className="mb-6">
                <form className="relative" onSubmit={(e) => e.preventDefault()}>
                  <Input
                    placeholder="Search books..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    fullWidth
                  />
                  <Search size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                </form>
              </div>
              
              {/* Categories */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-2">Categories</h3>
                <ul className="space-y-2">
                  {categories.map((category, index) => (
                    <li key={index}>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="category"
                          checked={selectedCategory === category}
                          onChange={() => setSelectedCategory(category)}
                          className="text-blue-900 focus:ring-blue-900"
                        />
                        <span className="text-sm text-gray-700">{category}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Price Range */}
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Price Range</h3>
                <div className="mb-2 flex justify-between text-sm text-gray-600">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
                <input 
                  type="range"
                  min="0"
                  max="100"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                  className="w-full mb-2"
                />
                <input 
                  type="range"
                  min="0"
                  max="100"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full"
                />
              </div>
            </div>
          </div>
          
          {/* Books Grid */}
          <div className="flex-grow md:ml-6">
            {filteredBooks.length > 0 ? (
              <>
                <div className="mb-4 text-sm text-gray-600">
                  Showing {filteredBooks.length} {filteredBooks.length === 1 ? 'book' : 'books'}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                  {filteredBooks.map(book => (
                    <BookCard key={book.id} book={book} />
                  ))}
                </div>
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <h2 className="text-xl font-medium text-gray-900 mb-2">No books found</h2>
                <p className="text-gray-600 mb-6">
                  Try adjusting your filters to find what you're looking for.
                </p>
                <Button onClick={handleClearFilters}>Clear Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrowsePage;